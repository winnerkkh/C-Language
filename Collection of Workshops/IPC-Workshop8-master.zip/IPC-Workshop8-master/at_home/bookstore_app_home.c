/*
Name:
Student number:
Email:
Workshop:
Section:
Date:
*/

#include <stdio.h>